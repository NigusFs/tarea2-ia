import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import pairwise_distances_argmin_min
from mpl_toolkits.mplot3d import Axes3D

plt.rcParams['figure.figsize'] = (16, 9)
plt.style.use('ggplot')

#Dataset

dataframe = pd.read_csv('games.csv') #https://www.kaggle.com/datasnaek/league-of-legends
#print(dataframe.head())


X = np.array(dataframe[["t1_inhibitorKills","t1_baronKills","t1_towerKills"]])
y = np.array(dataframe['winner']) #arreglo de 1 y 2, el cual indica el gandor de la partida.

fig = plt.figure("Dataset")
ax = Axes3D(fig)

colours=['black','blue','red'] #blue team 1, red team2
aux=[]
for fila in y:
	aux.append(colours[fila]) #le asigna un color a la partida segun el ganador

ax.set_xlabel('Inhibidores destruidos por el equipo_1')
ax.set_ylabel('Barones eliminados por el equipo_1')
ax.set_zlabel('Torres destruidas por el equipo_1')

ax.scatter(X[:, 0], X[:, 1], X[:, 2], c=aux,s=60) #se grafica, utilizando los colores almacenados en el arreglo aux

###

#K-Means

k_means = KMeans(n_clusters=2).fit(X)
centroides = k_means.cluster_centers_
print(centroides)


labels = k_means.predict(X)
C = k_means.cluster_centers_
colours=['blue','red']
aux=[]

for fila in labels:
    aux.append(colours[fila])
 
fig = plt.figure("K-means")
ax = Axes3D(fig)
ax.scatter(X[:, 0], X[:, 1], X[:, 2], c=aux,s=60)
ax.scatter(C[:, 0], C[:, 1], C[:, 2], marker='*', c=colours, s=1000)
ax.set_xlabel('Inhibidores destruidos por el equipo_1')
ax.set_ylabel('Barones eliminados por el equipo_1')
ax.set_zlabel('Torres destruidas por el equipo_1')


plt.show()

###
